/**
 * @returns String containing the current senna version
 */

const version = '<%= version %>';

export default version;