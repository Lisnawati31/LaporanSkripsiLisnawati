# Basic

Basic example of routing forms using Senna.js.

## Setup

1. Install NodeJS >= [v0.12.0](http://nodejs.org/dist/v0.12.0/), if you don't have it yet.

2. Install global dependencies:

  ```
  npm install
  ```

3. Run the server:

  ```
  node server.js
  ```

4. Open `http://localhost:3000/examples/form/` on the browser.
